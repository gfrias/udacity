MatrixXf m;
m.setRandom(3, 3);
cout << m << endl;
